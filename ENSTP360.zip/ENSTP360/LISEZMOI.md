# ENSTP 360° — notes de mise en ligne

## Contenu du dossier

| Fichier | Rôle |
|---|---|
| `index.html` | Le site complet (toutes les rubriques, l’emploi du temps, la recherche, l’AI 360°, la connexion Supabase) |
| `news.json` | Les actualités de la rubrique **Nos actualités** (à modifier pour publier) |
| `images/` | Logo, nouvelle image d’accueil, SSC et aperçus des PDF |
| `documents/` | `Demande_certificat_scolarite_francais.pdf`, `Demande_attestation_classement.pdf` |

Pour mettre en ligne, remplacez le contenu du dépôt GitHub `zwfh6trskt-bot/ENSTP` par ce dossier (mêmes noms de fichiers et de dossiers).

## Publier une actualité (Nos actualités)

Le site charge les actualités dans cet ordre :

1. la table Supabase `news`, si elle existe et contient des lignes ;
2. sinon le fichier `news.json` ;
3. sinon la liste intégrée dans `index.html`.

La page d’accueil affiche automatiquement les **3 plus récentes** (triées par date).

### Option simple : `news.json`

Ajoutez un objet en haut de la liste, puis enregistrez le fichier sur GitHub :

```json
{
  "date": "2026-11-20",
  "title": "Titre de la publication",
  "summary": "Une ou deux phrases de résumé.",
  "image": "https://… (adresse de l’image de la publication)",
  "url": "https://www.facebook.com/ENSTP.ecole/posts/… (lien vers la publication d’origine)",
  "source": "facebook"
}
```

- `source` : `"facebook"` pour une publication de la page Facebook ENSTP, `"site"` pour une publication de enstp.edu.dz. Le filtre « Facebook ENSTP » apparaît automatiquement dès qu’une actualité Facebook existe.
- `url` est obligatoire : chaque actualité renvoie vers sa publication d’origine.
- Pour récupérer le lien d’une publication Facebook : menu « … » de la publication → *Copier le lien*.
- Pour l’image : clic droit sur l’image de la publication → *Copier l’adresse de l’image*, ou téléversez l’image dans `images/news/` et indiquez `images/news/nom.jpg`.

### Option sans toucher au code : table Supabase `news`

Le site utilise déjà Supabase (enseignants, stages, lieux, FAQ). Créez une table `news` avec les colonnes `date` (date), `title`, `summary`, `image`, `url`, `source` (text) et une règle de lecture publique (RLS : `select` pour `anon`). Les lignes ajoutées depuis le tableau de bord Supabase apparaissent sur le site sans republier.

## Pourquoi pas une récupération automatique depuis Facebook ?

La lecture des publications d’une Page passe par l’API Graph de Meta. Elle demande un jeton d’accès de la Page, obtenu par un administrateur de la page ENSTP, avec une application Meta et des autorisations soumises à validation. Ce jeton est secret : il ne peut pas être placé dans un site statique comme GitHub Pages, où tout le code est public.

Une intégration fiable demanderait donc :

1. l’accord et l’accès d’un administrateur de la page Facebook ENSTP ;
2. une application Meta validée ;
3. un petit serveur (par exemple une Edge Function Supabase) qui garde le jeton et copie régulièrement les publications dans la table `news`.

Tant que ces trois conditions ne sont pas réunies, la gestion manuelle ci-dessus est la solution fiable. Le site est déjà prêt pour l’étape 3 : il lit la table `news` en priorité.

Les 8 actualités de départ proviennent de la page officielle https://enstp.edu.dz/fr/news-actualites (consultée le 16 novembre 2026), car la page Facebook bloque la lecture automatique.

## Points à vérifier (sources en désaccord ou incomplètes)

La version du site principal a été conservée dans chaque cas.

- **Téléphone** : le site principal indique +213 (0) 23 70 19 04. Une partie du site officiel enstp.edu.dz affiche 028 25 65 32 (fax 028 25 69 84). À confirmer auprès de l’école.
- **DMS / DIMS** : le site principal utilise les deux noms pour le département Matériaux et Structures. Les deux ont été conservés tels quels.
- **DIGITs’26** : une annonce officielle du 31/10 donne les dates du 1er au 3 décembre 2026. Celle du 14/11 annonce le report au 12 – 14 décembre 2026.
- **Image `images/tacozza.jpg`** et **photos des emplois du temps `images/IMG_2103.jpeg` … `IMG_2111.jpeg`** : ces fichiers sont appelés par le site principal mais absents du dépôt. Ajoutez-les dans `images/` ; en attendant, la carte Tacozza affiche une vignette neutre et le bouton « Télécharger l’emploi du temps » reste masqué.
- **Photos complémentaires** (Alger, salles de sport, clubs, résidence Garidi 1, campus) : elles sont chargées depuis l’ancien site ENSTP 360 (enstp-student-atlas.lovable.app). Si cet ancien site est supprimé, elles disparaîtront. Pour les garder durablement, enregistrez-les dans `images/` et mettez à jour les adresses dans `index.html` (objet `IMG`, et champs `i:` des tableaux `GYM` et `ALG`).
- **ENSTP NAV** n’a pas pu être lu (le site ne s’affiche que dans un navigateur). Son contenu propre n’est donc pas intégré.
